rpnCE 0.8.0 - an RPN calculator for the TI-84 Plus CE
==========================================================

An HP-style RPN calculator with scientific functions, statistics, TVM,
real and complex arithmetic, units, BASE arithmetic, and dates and times.

Files
-----
  rpnCE-0.8.0.8xp       the program
  rpnCEres-0.8.0.8xv    its menus, unit tables and HELP pages (required)
  readme.txt           installation, documentation and support
  LICENSE              redistribution terms
  rpnCE-0.8.0-*.png     stack, TVM and unit-conversion screenshots
  rpnCE-promo1.gif      animated program preview

The images are for viewing on your computer; only the program, resources
and required CE libraries need to be sent to the calculator.

Source builds write bin/rpnCE.8xp and bin/rpnCEres.8xv; packaged builds
use the versioned filenames above.

rpnCE also needs the CE C libraries (clibs.8xg), which many CE programs
use. If you don't have them, download clibs.8xg from
https://github.com/CE-Programming/libraries/releases

Installing
----------
1. Send rpnCE-0.8.0.8xp, rpnCEres-0.8.0.8xv and clibs.8xg with TI Connect
   CE. All three can stay in archive memory.
2. Launch using the native-program method supported by your OS or
   launcher. On OS versions that support it, use Asm(prgmRPNCE).
   Newer OS versions need native-program support enabled first; follow
   the current arTIfiCE instructions for your exact model and OS:
   https://yvantt.github.io/arTIfiCE/

rpnCE-0.8.0.8xp and rpnCEres-0.8.0.8xv must come from the same release. If RPNCEres
is missing or from a different version, rpnCE says so when it starts.

Your data
---------
rpnCE saves the stack, registers, statistics and settings when you quit
(2ND QUIT) in RPNCEdat and RPNCEcfg. Saved data uses version 6 and stores
complete real, complex, DATE and unit values together. Deleting the private
state does not clear shared TI-OS TVM values or reset the clock.

Upgrading from 0.7.0 or earlier
-------------------------------
Complex-number support changed how every value is stored, so 0.8.0 does not
read the RPNCEdat saved by 0.7.0 and earlier. The first start shows an empty
stack, registers and statistics, and the old RPNCEdat is replaced when you
quit. Note any values you need before upgrading. The screen tint, DATE
settings and decimal separator in RPNCEcfg carry over. Delete RPNCEunt if a
0.7.0 installation left one; 0.8.0 does not use it.

Getting started
---------------
RPN calculations use ENTER to separate numbers, followed by an operation.
The current number is X; the previous number is Y.

  2 ENTER 3 +           5
  MATH                  the menu tree (ON goes back)
  MODE                  display format, angle mode, and more
  2ND 0                 on-device HELP
  2ND QUIT              save and exit

Number modes
------------
Fresh state starts in DEG, DEC, RRES and RECT. These defaults have no
status labels; ALL means FIX with all display digits. RAD, CRES,
PRAD/PDEG, HEX/OCT/BIN and CF appear when active. Saved modes are restored.

In DEC, 3 then 2ND . then 4 ENTER enters 3 + 4i in one stack level.
2ND APPS enters a polar pair; 2ND X,T,theta,n joins/splits with LINK.
See the Complex numbers chapter of the User Guide for illustrated examples.

User documentation
------------------
The illustrated User Guide explains the stack, registers, menus and
functions, with worked examples:
https://github.com/jacober-calc/rpnCE/blob/main/docs/USER_GUIDE.md

Key and menu reference:
https://github.com/jacober-calc/rpnCE/blob/main/docs/KEYS.md

Bug reports and issues
----------------------
Check existing issues, or report a problem at:
https://github.com/jacober-calc/rpnCE/issues

Include the rpnCE version (shown in HELP / ABOUT), calculator model,
TI-OS version, exact keys and inputs, expected result and actual result.
Mention relevant settings such as angle mode, units or time zones.

Project and source code:
https://github.com/jacober-calc/rpnCE
